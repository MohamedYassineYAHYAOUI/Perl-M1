#!/usr/bin/perl

use strict;
use warnings;
use CGI;
use DBI;



my $source = 'dbi:Pg:host=sqletud.u-pem.fr;dbname=myahya01_db';
my $base = DBI->connect($source, 'myahya01', 'yu8uiuW3jf') or die('connect:'.$DBI::errstr);


print "Content-Type: text/html\n\n";

print "
<!DOCTYPE html>
<html>
<head>
	<title>Exo 6</title>
</head>
	<body>
	<p> Saisie d'utilisateur</p>";
	